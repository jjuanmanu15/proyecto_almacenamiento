from sqlalchemy import Column, Integer, String, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from app.db.mysql import Base


class HistorialContrasenasModel(Base):
    __tablename__ = "historialcontrasenas"

    idHistorial = Column(Integer, primary_key=True, index=True, autoincrement=True)
    idPersona = Column(Integer, ForeignKey("persona.idPersona"), nullable=False)
    contrasenaHash = Column(String(255), nullable=False)
    fechaCambio = Column(DateTime, nullable=False)

    persona = relationship("PersonaModel", back_populates="historial_contrasenas")
