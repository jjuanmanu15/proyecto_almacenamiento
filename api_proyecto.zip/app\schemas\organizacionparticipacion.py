from enum import Enum
from pydantic import BaseModel, ConfigDict, Field
from typing import Optional

# Definimos el Enum correspondiente a la columna participaRepresentante
class ParticipaRepresentanteEnum(str, Enum):
    si = "si"
    no = "no"

class OrganizacionParticipacionBase(BaseModel):
    idEvento: int
    idOrganizacion: int
    participaRepresentante: ParticipaRepresentanteEnum
    certificadoParticipacion: Optional[str] = Field(None, max_length=200)
    nombreParticipanteSustituto: Optional[str] = Field(None, max_length=200)

class OrganizacionParticipacionCrear(OrganizacionParticipacionBase):
    pass

class OrganizacionParticipacionActualizar(BaseModel):
    idEvento: Optional[int] = None
    idOrganizacion: Optional[int] = None
    participaRepresentante: Optional[ParticipaRepresentanteEnum] = None
    certificadoParticipacion: Optional[str] = None
    nombreParticipanteSustituto: Optional[str] = None

class OrganizacionParticipacion(OrganizacionParticipacionBase):
    id: int = Field(..., alias="idParticipacionExterna")
    model_config = ConfigDict(from_attributes=True)

