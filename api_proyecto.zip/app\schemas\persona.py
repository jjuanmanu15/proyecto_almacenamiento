from pydantic import BaseModel, ConfigDict, Field
from typing import Optional

class PersonaBase(BaseModel):
    nombre: str = Field(..., min_length=1, max_length=100)
    identificacion: str = Field(..., min_length=5, max_length=20)
    correo: str = Field(..., max_length=100)
    telefono: Optional[str] = Field(None, max_length=20)

class PersonaCrear(PersonaBase):
    pass

class PersonaActualizar(BaseModel):
    nombre: Optional[str] = None
    identificacion: Optional[str] = None
    correo: Optional[str] = None
    telefono: Optional[str] = None

class Persona(PersonaBase):
    id: int = Field(..., alias="idPersona")
    model_config = ConfigDict(from_attributes=True)
