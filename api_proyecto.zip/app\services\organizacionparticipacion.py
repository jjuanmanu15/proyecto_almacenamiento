from sqlalchemy.exc import IntegrityError
from fastapi import HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from typing import Sequence

from app.crud import organizacionparticipacion as org_part_crud
from app.models.organizacionparticipacion import OrganizacionParticipacionModel
from app.schemas.organizacionparticipacion import OrganizacionParticipacionCrear, OrganizacionParticipacionActualizar


async def crear_org_part_service(session: AsyncSession, nueva_participacion: OrganizacionParticipacionCrear) -> OrganizacionParticipacionModel:
    try:
        return await org_part_crud.crear_org_part(session, nueva_participacion)
    except IntegrityError as e:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Ya existe un registro de participación para esa organización y evento."
        ) from e


async def listar_org_part_service(session: AsyncSession) -> Sequence[OrganizacionParticipacionModel]:
    return await org_part_crud.listar_org_part(session)


async def buscar_org_part_por_id_service(session: AsyncSession, org_part_id: int) -> OrganizacionParticipacionModel:
    registro = await org_part_crud.buscar_org_part_por_id(session, org_part_id)
    if not registro:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No existe participación con id {org_part_id}"
        )
    return registro


async def eliminar_org_part_por_id_service(session: AsyncSession, org_part_id: int) -> None:
    registro = await org_part_crud.buscar_org_part_por_id(session, org_part_id)
    if not registro:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No existe participación con id {org_part_id}"
        )
    eliminado = await org_part_crud.eliminar_org_part_por_id(session, org_part_id)
    if not eliminado:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="No se pudo eliminar la participación"
        )
    await session.commit()


async def editar_org_part_por_id_service(session: AsyncSession, org_part_id: int, org_part_actualizar: OrganizacionParticipacionActualizar):
    registro = await org_part_crud.buscar_org_part_por_id(session, org_part_id)
    if not registro:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No existe participación con id {org_part_id}"
        )
    actualizado = await org_part_crud.editar_org_part_por_id(session, org_part_id, org_part_actualizar)
    if not actualizado:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="No se pudo actualizar la participación"
        )
    await session.commit()
    return await org_part_crud.buscar_org_part_por_id(session, org_part_id)
